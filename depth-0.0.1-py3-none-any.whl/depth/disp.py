import torch
import torch.nn as nn
import torchvision.transforms as transforms
from PIL import Image
import time
import numpy as np
import cv2
from .models import *

# 固定参数设定
KITTI = '2015'
# loadmodel = r'G:\mobelnetV11v2\250320kiwi_1_mask\best_3px.tar'
# leftimg_path = r'G:\data\datasets_kiwi\left/000001.png'
# rightimg_path = r'G:\data\datasets_kiwi\right/000001.png'

model_type = 'stackhourglass'
max_disp = 192
use_cuda = torch.cuda.is_available()
random_seed = 1

# 设定随机种子
torch.manual_seed(random_seed)
if use_cuda:
    torch.cuda.manual_seed(random_seed)

def my_load_model(loadmodel):
# 模型初始化
    if model_type == 'stackhourglass':
        lsp_channel = 4
        lsp_mode = 'separate'
        lsp_width = 3
        lsp_dilation = [1, 2, 4, 8]
        affinity_settings = {
            'win_w': lsp_width,
            'win_h': lsp_width,
            'dilation': lsp_dilation
        }
        udc = True
        model = anet(max_disp, use_concat_volume=True, struct_fea_c=lsp_channel,
                    fuse_mode=lsp_mode, affinity_settings=affinity_settings, udc=udc)
    elif model_type == 'basic':
        model = basic(max_disp)
    else:
        print('没有这种模型类型')
        exit()
    if use_cuda:
        model = model.cuda()

    # 加载模型
    if loadmodel:
        print(f"加载模型权重: {loadmodel}")
        checkpoint = torch.load(loadmodel, map_location='cuda')
        state_dict = checkpoint['state_dict']
        # 统一处理多GPU参数前缀
        state_dict = {k.replace('module.', ''): v for k, v in state_dict.items()}
        model.load_state_dict(state_dict)
    model = nn.DataParallel(model)
    print('模型参数数量: {}'.format(sum(p.data.nelement() for p in model.parameters())))
    return model

# 转换和测试函数
normal_mean_var = {'mean': [0.485, 0.456, 0.406], 'std': [0.229, 0.224, 0.225]}
infer_transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize(**normal_mean_var)
])


def test(model, imgL, imgR):
    model.eval()
    if use_cuda:
        imgL, imgR = imgL.cuda(), imgR.cuda()
    imgL, imgR = imgL.unsqueeze(0), imgR.unsqueeze(0)

    with torch.no_grad():
        _, _, disp = model(imgL, imgR)

    disp = torch.squeeze(disp)
    return disp.data.cpu().numpy()


# 主函数
def get_disp_path(model, leftimg_path, rightimg_path, width, height):
    imgL_o = Image.open(leftimg_path).convert('RGB')
    imgR_o = Image.open(rightimg_path).convert('RGB')

    imgL_o = imgL_o.resize((width, height))
    imgR_o = imgR_o.resize((width, height))
    # imgL_o = imgL_o.resize((960, 512))
    # imgR_o = imgR_o.resize((960, 512))
    # imgL_o = imgL_o.resize((int(2208), int(1216)))
    # imgR_o = imgR_o.resize((int(2208), int(1216)))
    # imgL_o = imgL_o.resize((int(1536/2), int(2048/2)))
    # imgR_o = imgR_o.resize((int(1536/2), int(2048/2)))
    # imgL_o = imgL_o.resize((1216, 1216))
    # imgR_o = imgR_o.resize((1216, 1216))
    # imgL_o = imgL_o.resize((768,2208))
    # imgR_o = imgR_o.resize((768,2208))
    # imgL_o = imgL_o.resize((1536, 2048))
    # imgR_o = imgR_o.resize((1536, 2048))

    imgL = infer_transform(imgL_o)
    imgR = infer_transform(imgR_o)

    start_time = time.time()
    pred_disp = test(model, imgL, imgR)
    print('检测时间: %.2f 秒' % (time.time() - start_time))
    return pred_disp

    # depth = (2873.41333122683 * 18.8689953791335 / 2) / pred_disp
    # # DEPTH= cv2.resize(depth,(3072,4096))
    # depth_img = Image.fromarray(depth.astype(np.uint16))
    # depth_img.save('depth_img.png')

    # img = Image.fromarray((pred_disp * 256).astype(np.uint16))
    # img.save('Test_disparity.png')

    # disparity_color = cv2.applyColorMap(cv2.convertScaleAbs(pred_disp, alpha=256 / max_disp), cv2.COLORMAP_JET)
    # cv2.imwrite('disparity_color.png', disparity_color)

def get_disp(model, imgL_o, imgR_o):
    # imgL_o = Image.open(leftimg_path).convert('RGB')
    # imgR_o = Image.open(rightimg_path).convert('RGB')

    # imgL_o = imgL_o.resize((width, height))
    # imgR_o = imgR_o.resize((width, height))
    # imgL_o = imgL_o.resize((960, 512))
    # imgR_o = imgR_o.resize((960, 512))
    # imgL_o = imgL_o.resize((int(2208), int(1216)))
    # imgR_o = imgR_o.resize((int(2208), int(1216)))
    # imgL_o = imgL_o.resize((int(1536/2), int(2048/2)))
    # imgR_o = imgR_o.resize((int(1536/2), int(2048/2)))
    # imgL_o = imgL_o.resize((1216, 1216))
    # imgR_o = imgR_o.resize((1216, 1216))
    # imgL_o = imgL_o.resize((768,2208))
    # imgR_o = imgR_o.resize((768,2208))
    # imgL_o = imgL_o.resize((1536, 2048))
    # imgR_o = imgR_o.resize((1536, 2048))

    imgL = infer_transform(imgL_o)
    imgR = infer_transform(imgR_o)

    start_time = time.time()
    pred_disp = test(model, imgL, imgR)
    print('检测时间: %.2f 秒' % (time.time() - start_time))
    return pred_disp

if __name__ == '__main__':
    model = my_load_model(r"D:\kiwirobot\mode\stereo_matching\250324HCDatasets\best_loss.pth")
    pred_disp = get_disp(model,r"D:\kiwirobot-zed\captured_images_20250327_172108\left_20250327_172108.png", r"D:\kiwirobot-zed\captured_images_20250327_172108\right_20250327_172108.png",1280,736)
    depth = (2873.41333122683 * 18.8689953791335 / 2) / pred_disp
    # DEPTH= cv2.resize(depth,(3072,4096))
    depth_img = Image.fromarray(depth.astype(np.uint16))
    depth_img.save('1depth_img.png')

    img = Image.fromarray((pred_disp * 256).astype(np.uint16))
    img.save('1Test_disparity.png')

    disparity_color = cv2.applyColorMap(cv2.convertScaleAbs(pred_disp, alpha=256 / max_disp), cv2.COLORMAP_JET)
    cv2.imwrite('1disparity_color.png', disparity_color)