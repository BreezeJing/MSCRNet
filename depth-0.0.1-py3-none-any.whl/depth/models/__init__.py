from .basic import PSMNet as basic
from .stackhourglass import MYNet as stackhourglass
from .anet import MYNet as anet

